
import gradio as gr
import os
import torch

from DenseNet161 import create_densenet161
from timeit import default_timer as timer

class_names = ["Amanita Muscaria", "Amanita Vaginata", "Boletus Edulis", "Boletus Erythropus"]
edibility_list = ["Toxic", "Not edible", "Great", "Toxic when raw"]

densenet161, transform = create_densenet161(output_shape = 4, seed = 42)

densenet161.load_state_dict(torch.load(f="20_epochs_DenseNet161.pth", map_location=torch.device("cpu")))

def predict(img):
  """
  Transforms and makes prediction on an image and return prediction and time.
  """

  start_time = timer()

  img = transform(img).unsqueeze(0)

  densenet161.eval()
  with torch.inference_mode():
    pred_probs = torch.softmax(densenet161(img), dim=1)

  pred_labels_and_probs = {class_names[i]: float(pred_probs[0][i]) for i in range(len(class_names))}

  pred_info = edibility_list[torch.argmax(pred_probs)]

  pred_time = round(timer() - start_time, 5)

  return pred_labels_and_probs, pred_info, pred_time

title = "Shroom Vision 4 🍄"
description = "A DenseNet161 feature extractor computer vision model to classify images of mushrooms as Amanita Muscaria, Amanita Vaginata, Boletus Edulis or Boletus Erythropus."
article = "WARNING: This app is purely for demonstration purposes, has no application intent, and therefore whatever answers it gives are not to be considered reliable in any case. Only accurate mycological analyses can give reliable results about whether a mushroom belongs to a species and, therefore, whether it is edible. More informations on this project and full code are available on my [GitHub](https://github.com/Sim98B/ShroomVision/tree/main)"

example_list = [["examples/" + example] for example in os.listdir("examples")]

demo = gr.Interface(fn = predict,
                    inputs=gr.Image(type="pil"),
                    outputs=[gr.Label(num_top_classes = 4, label = "Predictions"),
                             gr.Label(num_top_classes = 1, label = "Edibility"),
                             gr.Number(label="Prediction time (s)")],
                    examples=example_list,
                    title=title,
                    description=description,
                    article=article)

demo.launch()
